# mypackage
This library was used for educational purposes

## Building this package locally
'python setup.py sdist'
